# FixNow Mechanics — One-page WhatsApp-first site

Deploy: upload to Vercel/Netlify/Cloudflare Pages.  
All CTAs open WhatsApp to 447444255968.

Files:
- index.html
- /assets/logo.svg (dark)
- /assets/favicon.svg
- robots.txt, sitemap.xml

To update the phone later: search in index.html for 'https://wa.me/'.
